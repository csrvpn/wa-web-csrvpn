# whatsapp-web-bot

```bash
git clone https://github.com/apriansyahrs/whatsapp-web-bot
cd whatsapp-web-bot
npm install
Copy API keys openAI https://beta.openai.com/account/api-keys paste di config.js
npm run dev
```
